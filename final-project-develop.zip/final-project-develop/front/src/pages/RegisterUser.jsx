
const RegisterUser = () => {
  return (
    <>
        
    </>
  )
}

export default RegisterUser