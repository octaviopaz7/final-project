import ContactTable from '../components/ContactTable'

const Contact = () => {
  return (
    <>
        <section className='contact-section d-flex flex-column align-items-center justify-content-center'>
        <ContactTable />
        </section>
    </>
  )
}

export default Contact