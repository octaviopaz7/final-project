
const Error = () => {
  return (
    <div>
      <h1>Página no encontrada</h1>
    </div>
  )
}

export default Error
