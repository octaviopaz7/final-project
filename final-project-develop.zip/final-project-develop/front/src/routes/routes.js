export const home = "/";

export const services = "/servicios";

export const appointments = "/turnos";

export const contact = "/contactos";

export const users = "/usuarios";